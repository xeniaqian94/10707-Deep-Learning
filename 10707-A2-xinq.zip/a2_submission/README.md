# 10707-Deep-Learning

Please cd assignment*/ for individual documentation. The code is located at assignment*/code/

For any question, please contact Xin Qian @ xinq@cs.cmu.edu

Thanks ;D
